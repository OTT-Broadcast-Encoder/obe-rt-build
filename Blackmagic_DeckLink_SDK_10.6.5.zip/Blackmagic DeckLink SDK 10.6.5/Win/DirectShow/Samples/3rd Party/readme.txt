The files contained within this directory have been kindly provided by developers using languages other than C++.  Blackmagic does not maintain these files, only includes them with the DirectShow SDK.  Please contact the developers via the Developer mailing list for further information, bug reports and help or the contact the developer directly.

Blackmagic Design.