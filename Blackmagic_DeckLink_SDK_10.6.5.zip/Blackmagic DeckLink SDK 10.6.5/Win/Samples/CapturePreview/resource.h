//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CapturePreview.rc
//
#define IDD_CAPTUREPREVIEW_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_INPUT_DEVICE_COMBO          1000
#define IDC_INPUT_MODE_COMBO            1001
#define IDC_AUTODETECT_FORMAT_CHECK     1002
#define IDC_START_STOP_BUTTON           1003
#define IDC_INVALID_INPUT_STATIC        1004
#define IDC_VITC_TC_F1_STATIC           1007
#define IDC_VITC_UB_F1_STATIC           1008
#define IDC_VITC_TC_F2_STATIC           1009
#define IDC_VITC_UB_F2__STATIC          1010
#define IDC_RP188_VITC1_TC_STATIC       1011
#define IDC_RP188_VITC1_UB_STATIC       1012
#define IDC_RP188_VITC2_TC_STATIC       1013
#define IDC_RP188_VITC2_TC__STATIC      1014
#define IDC_RP188_LTC_TC_STATIC         1015
#define IDC_RP188_LTC_UB_STATIC         1016
#define IDC_PREVIEW_STATIC              1017
#define IDC_PREVIEW_BOX                 1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
